#!/usr/local/bin/ruby

class CheckboxPage < CKComponent
	attr_accessor :button1, :button2, :button3
end
