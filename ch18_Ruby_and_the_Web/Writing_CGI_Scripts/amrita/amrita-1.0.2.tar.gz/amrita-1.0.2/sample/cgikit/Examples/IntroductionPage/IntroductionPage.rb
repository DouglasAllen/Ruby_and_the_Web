#!/usr/local/bin/ruby

class IntroductionPage < CKComponent
end
