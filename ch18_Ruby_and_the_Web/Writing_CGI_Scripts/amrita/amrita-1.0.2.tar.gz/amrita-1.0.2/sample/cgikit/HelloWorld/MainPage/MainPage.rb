#
# MainPage.rb
#

class MainPage < CKComponent
	def sayHello
		"Hello World!"
	end
end


